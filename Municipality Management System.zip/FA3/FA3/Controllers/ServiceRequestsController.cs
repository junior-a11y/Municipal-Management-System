﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FA3.Data;
using FA3.Models;

namespace FA3.Controllers
{
    public class ServiceRequestsController : Controller
    {
        private readonly FA3Context _context;
        private readonly ILogger<ServiceRequestsController> _logger;

        public ServiceRequestsController(FA3Context context, ILogger<ServiceRequestsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: ServiceRequests
        public async Task<IActionResult> Index()
        {
            var fA3Context = _context.ServiceRequest.Include(s => s.Citizen);
            return View(await fA3Context.ToListAsync());
        }

        // GET: ServiceRequests/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var serviceRequest = await _context.ServiceRequest
                .Include(s => s.Citizen)
                .FirstOrDefaultAsync(m => m.RequestID == id);
            if (serviceRequest == null)
            {
                return NotFound();
            }

            return View(serviceRequest);
        }

        // GET: ServiceRequests/Create
        public IActionResult Create()
        {
            ViewData["CitizenID"] = new SelectList(_context.CitizenManagement, "CitizenID", "FullName");
            return View();
        }

        // POST: ServiceRequests/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        // POST: ServiceRequests/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RequestID,CitizenID,ServiceType,RequestDate,Status")] ServiceRequest serviceRequest)
        {
            _logger.LogInformation("Create POST method called with CitizenID: {CitizenID}, ServiceType: {ServiceType}",
                serviceRequest.CitizenID, serviceRequest.ServiceType);

            // Clear any previous validation errors
            ModelState.Clear();

            // Re-validate the model
            if (serviceRequest.CitizenID <= 0)
            {
                ModelState.AddModelError("CitizenID", "The Citizen field is required.");
            }

            if (string.IsNullOrWhiteSpace(serviceRequest.ServiceType))
            {
                ModelState.AddModelError("ServiceType", "The Service Type field is required.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Set default values if not provided
                    if (serviceRequest.RequestDate == default)
                    {
                        serviceRequest.RequestDate = DateTime.Now;
                    }

                    if (string.IsNullOrWhiteSpace(serviceRequest.Status))
                    {
                        serviceRequest.Status = "Pending";
                    }

                    _context.Add(serviceRequest);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error creating service request");
                    ModelState.AddModelError("", $"Error saving data: {ex.Message}");

                    // Log inner exception details
                    if (ex.InnerException != null)
                    {
                        _logger.LogError(ex.InnerException, "Inner exception details");
                        ModelState.AddModelError("", $"Additional details: {ex.InnerException.Message}");
                    }
                }
            }
            else
            {
                // Log all validation errors
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        _logger.LogWarning("Validation error for {Key}: {ErrorMessage}",
                            state.Key, error.ErrorMessage);
                    }
                }
            }

            // If we reach here, something went wrong
            ViewData["CitizenID"] = new SelectList(_context.CitizenManagement, "CitizenID", "FullName", serviceRequest.CitizenID);
            return View(serviceRequest);
        }

        // GET: ServiceRequests/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var serviceRequest = await _context.ServiceRequest.FindAsync(id);
            if (serviceRequest == null)
            {
                return NotFound();
            }

            // Make sure we're passing the right data to the dropdown
            ViewData["CitizenID"] = new SelectList(_context.CitizenManagement, "CitizenID", "FullName", serviceRequest.CitizenID);

            // Log what we're returning to the view
            _logger.LogInformation("Edit GET: Found request {RequestID} with CitizenID {CitizenID}",
                serviceRequest.RequestID, serviceRequest.CitizenID);

            return View(serviceRequest);
        }

        // POST: ServiceRequests/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("RequestID,CitizenID,ServiceType,RequestDate,Status")] ServiceRequest serviceRequest)
        {
            _logger.LogInformation("Edit POST method called for ID: {ID}, with CitizenID: {CitizenID}, ServiceType: {ServiceType}",
                id, serviceRequest.CitizenID, serviceRequest.ServiceType);

            if (id != serviceRequest.RequestID)
            {
                _logger.LogWarning("Edit POST: ID mismatch - URL ID: {UrlID}, Model ID: {ModelID}",
                    id, serviceRequest.RequestID);
                return NotFound();
            }

            // Clear any previous validation errors
            ModelState.Clear();

            // Re-validate the model
            if (serviceRequest.CitizenID <= 0)
            {
                ModelState.AddModelError("CitizenID", "The Citizen field is required.");
            }

            if (string.IsNullOrWhiteSpace(serviceRequest.ServiceType))
            {
                ModelState.AddModelError("ServiceType", "The Service Type field is required.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Set default values if not provided
                    if (serviceRequest.RequestDate == default)
                    {
                        serviceRequest.RequestDate = DateTime.Now;
                    }

                    if (string.IsNullOrWhiteSpace(serviceRequest.Status))
                    {
                        serviceRequest.Status = "Pending";
                    }

                    _context.Update(serviceRequest);
                    await _context.SaveChangesAsync();
                    _logger.LogInformation("Edit POST: Successfully updated request ID: {ID}", id);
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!ServiceRequestExists(serviceRequest.RequestID))
                    {
                        _logger.LogWarning("Edit POST: Record with ID {ID} no longer exists", serviceRequest.RequestID);
                        return NotFound();
                    }
                    else
                    {
                        _logger.LogError(ex, "Concurrency exception updating request ID: {ID}", serviceRequest.RequestID);
                        ModelState.AddModelError("", "This record was modified by another user. Please try again.");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error updating service request ID: {ID}", serviceRequest.RequestID);
                    ModelState.AddModelError("", $"Error saving data: {ex.Message}");

                    if (ex.InnerException != null)
                    {
                        _logger.LogError(ex.InnerException, "Inner exception details");
                        ModelState.AddModelError("", $"Additional details: {ex.InnerException.Message}");
                    }
                }
            }
            else
            {
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        _logger.LogWarning("Validation error for {Key}: {ErrorMessage}",
                            state.Key, error.ErrorMessage);
                    }
                }
            }

            // If we get here, something went wrong
            ViewData["CitizenID"] = new SelectList(_context.CitizenManagement, "CitizenID", "FullName", serviceRequest.CitizenID);
            return View(serviceRequest);
        }

        // GET: ServiceRequests/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var serviceRequest = await _context.ServiceRequest
                .Include(s => s.Citizen)
                .FirstOrDefaultAsync(m => m.RequestID == id);
            if (serviceRequest == null)
            {
                return NotFound();
            }

            return View(serviceRequest);
        }

        // POST: ServiceRequests/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var serviceRequest = await _context.ServiceRequest.FindAsync(id);
            if (serviceRequest != null)
            {
                _context.ServiceRequest.Remove(serviceRequest);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ServiceRequestExists(int id)
        {
            return _context.ServiceRequest.Any(e => e.RequestID == id);
        }
    }
}
