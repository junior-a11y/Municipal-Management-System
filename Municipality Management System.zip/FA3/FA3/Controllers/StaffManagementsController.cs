﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FA3.Data;
using FA3.Models;

namespace FA3.Controllers
{
    public class StaffManagementsController : Controller
    {
        private readonly FA3Context _context;

        public StaffManagementsController(FA3Context context)
        {
            _context = context;
        }

        // GET: StaffManagements
        public async Task<IActionResult> Index()
        {
            return View(await _context.StaffManagement.ToListAsync());
        }

        // GET: StaffManagements/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var staffManagement = await _context.StaffManagement
                .FirstOrDefaultAsync(m => m.StaffID == id);
            if (staffManagement == null)
            {
                return NotFound();
            }

            return View(staffManagement);
        }

        // GET: StaffManagements/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: StaffManagements/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StaffID,FullName,Position,Department,Email,PhoneNumber,HireDate")] StaffManagement staffManagement)
        {
            if (ModelState.IsValid)
            {
                _context.Add(staffManagement);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(staffManagement);
        }

        // GET: StaffManagements/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var staffManagement = await _context.StaffManagement.FindAsync(id);
            if (staffManagement == null)
            {
                return NotFound();
            }
            return View(staffManagement);
        }

        // POST: StaffManagements/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("StaffID,FullName,Position,Department,Email,PhoneNumber,HireDate")] StaffManagement staffManagement)
        {
            if (id != staffManagement.StaffID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(staffManagement);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StaffManagementExists(staffManagement.StaffID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(staffManagement);
        }

        // GET: StaffManagements/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var staffManagement = await _context.StaffManagement
                .FirstOrDefaultAsync(m => m.StaffID == id);
            if (staffManagement == null)
            {
                return NotFound();
            }

            return View(staffManagement);
        }

        // POST: StaffManagements/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var staffManagement = await _context.StaffManagement.FindAsync(id);
            if (staffManagement != null)
            {
                _context.StaffManagement.Remove(staffManagement);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StaffManagementExists(int id)
        {
            return _context.StaffManagement.Any(e => e.StaffID == id);
        }
    }
}
