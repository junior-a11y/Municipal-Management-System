﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FA3.Data;
using FA3.Models;

namespace FA3.Controllers
{
    public class CitizenManagementsController : Controller
    {
        private readonly FA3Context _context;

        public CitizenManagementsController(FA3Context context)
        {
            _context = context;
        }

        // GET: CitizenManagements
        public async Task<IActionResult> Index()
        {
            return View(await _context.CitizenManagement.ToListAsync());
        }

        // GET: CitizenManagements/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var citizenManagement = await _context.CitizenManagement
                .FirstOrDefaultAsync(m => m.CitizenID == id);
            if (citizenManagement == null)
            {
                return NotFound();
            }

            return View(citizenManagement);
        }

        // GET: CitizenManagements/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CitizenManagements/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CitizenID,FullName,Address,PhoneNumber,Email,DateOfBirth,Registration")] CitizenManagement citizenManagement)
        {
            if (ModelState.IsValid)
            {
                _context.Add(citizenManagement);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(citizenManagement);
        }

        // GET: CitizenManagements/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var citizenManagement = await _context.CitizenManagement.FindAsync(id);
            if (citizenManagement == null)
            {
                return NotFound();
            }
            return View(citizenManagement);
        }

        // POST: CitizenManagements/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CitizenID,FullName,Address,PhoneNumber,Email,DateOfBirth,Registration")] CitizenManagement citizenManagement)
        {
            if (id != citizenManagement.CitizenID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(citizenManagement);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CitizenManagementExists(citizenManagement.CitizenID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(citizenManagement);
        }

        // GET: CitizenManagements/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var citizenManagement = await _context.CitizenManagement
                .FirstOrDefaultAsync(m => m.CitizenID == id);
            if (citizenManagement == null)
            {
                return NotFound();
            }

            return View(citizenManagement);
        }

        // POST: CitizenManagements/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var citizenManagement = await _context.CitizenManagement.FindAsync(id);
            if (citizenManagement != null)
            {
                _context.CitizenManagement.Remove(citizenManagement);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CitizenManagementExists(int id)
        {
            return _context.CitizenManagement.Any(e => e.CitizenID == id);
        }
    }
}
