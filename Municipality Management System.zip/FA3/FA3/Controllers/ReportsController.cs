﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FA3.Data;
using FA3.Models;

namespace FA3.Controllers
{
    public class ReportsController : Controller
    {
        private readonly FA3Context _context;
        private readonly ILogger<ReportsController> _logger;


        public ReportsController(FA3Context context, ILogger<ReportsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: Reports
        public async Task<IActionResult> Index()
        {
            var fA3Context = _context.Reports.Include(r => r.Citizen);
            return View(await fA3Context.ToListAsync());
        }

        // GET: Reports/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reports = await _context.Reports
                .Include(r => r.Citizen)
                .FirstOrDefaultAsync(m => m.ReportID == id);
            if (reports == null)
            {
                return NotFound();
            }

            return View(reports);
        }

        // GET: Reports/Create
        public IActionResult Create()
        {
            ViewData["CitizenID"] = new SelectList(_context.CitizenManagement, "CitizenID", "FullName"); 
            return View();
        }

        // POST: Reports/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ReportID,CitizenID,ReportType,Details,SubmissionDate,Status")] Reports reports)
        {
            _logger.LogInformation("Create POST method called with CitizenID: {CitizenID}, ReportType: {ReportType}",
                reports.CitizenID, reports.ReportType);

            ModelState.Clear();

            if (reports.CitizenID <= 0)
            {
                ModelState.AddModelError("CitizenID", "The Citizen field is required.");
            }

            if (string.IsNullOrWhiteSpace(reports.ReportType))
            {
                ModelState.AddModelError("ReportType", "The Report Type field is required.");
            }

            if (string.IsNullOrWhiteSpace(reports.Details))
            {
                ModelState.AddModelError("Details", "The Details field is required.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (reports.SubmissionDate == default)
                    {
                        reports.SubmissionDate = DateTime.UtcNow;  // Default to current time
                    }

                    if (string.IsNullOrWhiteSpace(reports.Status))
                    {
                        reports.Status = "Under Review";  // Default status
                    }

                    _context.Add(reports);
                    await _context.SaveChangesAsync();

                    _logger.LogInformation("Report created successfully with ReportID: {ReportID}", reports.ReportID);
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error creating report");

                    // Log inner exception details if available
                    if (ex.InnerException != null)
                    {
                        _logger.LogError(ex.InnerException, "Inner exception details");
                        ModelState.AddModelError("", $"Additional details: {ex.InnerException.Message}");
                    }
                    else
                    {
                        ModelState.AddModelError("", $"Error saving data: {ex.Message}");
                    }
                }
            }
            else
            {
                // Log all validation errors
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        _logger.LogWarning("Validation error for {Key}: {ErrorMessage}",
                            state.Key, error.ErrorMessage);
                    }
                }
            }

            // If we reached here, something went wrong; return the view with validation errors
            ViewData["CitizenID"] = new SelectList(_context.CitizenManagement, "CitizenID", "FullName", reports.CitizenID);
            return View(reports);
        }

        // GET: Reports/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                _logger.LogWarning("Edit GET: Report ID is null");
                return NotFound();
            }

            var report = await _context.Reports.FindAsync(id);
            if (report == null)
            {
                _logger.LogWarning("Edit GET: Report not found with ID: {ID}", id);
                return NotFound();
            }

            ViewData["CitizenID"] = new SelectList(_context.CitizenManagement, "CitizenID", "FullName", report.CitizenID);

            _logger.LogInformation("Edit GET: Found report ID {ReportID} with CitizenID {CitizenID}",
                report.ReportID, report.CitizenID);

            return View(report);
        }

        // POST: Reports/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ReportID,CitizenID,ReportType,Details,SubmissionDate,Status")] Reports reports)
        {
            _logger.LogInformation("Edit POST: Called for ReportID {ID}, CitizenID {CitizenID}, Type: {Type}, Status: {Status}",
                reports.ReportID, reports.CitizenID, reports.ReportType, reports.Status);

            if (id != reports.ReportID)
            {
                _logger.LogWarning("Edit POST: ID mismatch. URL ID: {UrlID}, Model ID: {ModelID}", id, reports.ReportID);
                return NotFound();
            }

            ModelState.Clear();

            if (reports.CitizenID <= 0)
            {
                ModelState.AddModelError("CitizenID", "The Citizen field is required.");
            }

            if (string.IsNullOrWhiteSpace(reports.ReportType))
            {
                ModelState.AddModelError("ReportType", "The Report Type field is required.");
            }

            if (string.IsNullOrWhiteSpace(reports.Details))
            {
                ModelState.AddModelError("Details", "The Details field is required.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(reports.Status))
                    {
                        reports.Status = "Under Review";
                    }

                    _context.Update(reports);
                    await _context.SaveChangesAsync();

                    _logger.LogInformation("Edit POST: Successfully updated Report ID: {ID}", id);
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!ReportsExists(reports.ReportID))
                    {
                        _logger.LogWarning("Edit POST: Report ID {ID} does not exist", reports.ReportID);
                        return NotFound();
                    }
                    else
                    {
                        _logger.LogError(ex, "Edit POST: Concurrency issue with Report ID: {ID}", reports.ReportID);
                        ModelState.AddModelError("", "This record was modified by someone else. Please try again.");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Edit POST: General error while updating Report ID: {ID}", reports.ReportID);
                    ModelState.AddModelError("", $"Error saving data: {ex.Message}");

                    if (ex.InnerException != null)
                    {
                        _logger.LogError(ex.InnerException, "Inner Exception:");
                        ModelState.AddModelError("", $"Details: {ex.InnerException.Message}");
                    }
                }
            }
            else
            {
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        _logger.LogWarning("Validation error for {Key}: {ErrorMessage}",
                            state.Key, error.ErrorMessage);
                    }
                }
            }

            ViewData["CitizenID"] = new SelectList(_context.CitizenManagement, "CitizenID", "FullName", reports.CitizenID);
            return View(reports);
        }

        // Helper method
        private bool ReportsExists(int id)
        {
            return _context.Reports.Any(e => e.ReportID == id);
        }


        // GET: Reports/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reports = await _context.Reports
                .Include(r => r.Citizen)
                .FirstOrDefaultAsync(m => m.ReportID == id);
            if (reports == null)
            {
                return NotFound();
            }

            return View(reports);
        }

        // POST: Reports/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reports = await _context.Reports.FindAsync(id);
            if (reports != null)
            {
                _context.Reports.Remove(reports);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
