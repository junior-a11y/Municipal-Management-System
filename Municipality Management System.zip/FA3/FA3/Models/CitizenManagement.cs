﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace FA3.Models
{
    public class CitizenManagement
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)] //auto-incrementation
        public int CitizenID { get; set; }

        [Required]
        public string FullName { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string PhoneNumber { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public DateOnly? DateOfBirth { get; set; }

        public DateTime Registration { get; set; } = DateTime.UtcNow;

        public virtual ICollection<ServiceRequest> ServiceRequests { get; set; } = new List<ServiceRequest>();
        public virtual ICollection<Reports> Reports { get; set; } = new List<Reports>();
    }
}
