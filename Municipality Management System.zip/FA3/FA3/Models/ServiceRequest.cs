﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace FA3.Models
{
    public class ServiceRequest
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)] //auto incrementation
        public int RequestID { get; set; }

        [Required]
        public int CitizenID { get; set; }

        [Required]
        public string ServiceType { get; set; }

        public DateTime RequestDate { get; set; } = DateTime.Now;

        public string Status { get; set; } = "Pending";

        //Navigation Property with Data Annotation
        [ForeignKey("CitizenID")]
        public virtual CitizenManagement Citizen { get; set; }
    }
}
