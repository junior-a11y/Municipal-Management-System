﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FA3.Models;

namespace FA3.Data
{
    public class FA3Context : DbContext
    {
        public FA3Context (DbContextOptions<FA3Context> options)
            : base(options)
        {
        }

        public DbSet<FA3.Models.CitizenManagement> CitizenManagement { get; set; } = default!;
        public DbSet<FA3.Models.ServiceRequest> ServiceRequest { get; set; } = default!;
        public DbSet<FA3.Models.StaffManagement> StaffManagement { get; set; } = default!;
        public DbSet<FA3.Models.Reports> Reports { get; set; } = default!;

    }
}
